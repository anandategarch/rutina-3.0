/**
 * Rutina 2.0 — seed data 35 hari.
 * Jalankan: bun prisma/seed.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// Deterministic RNG supaya seed stabil
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20250815);
const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];
const rint = (min: number, max: number) => Math.floor(rand() * (max - min + 1)) + min;
const rfloat = (min: number, max: number, d = 1) => Number((rand() * (max - min) + min).toFixed(d));

function dstr(offsetDaysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - offsetDaysAgo);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
const TODAY = dstr(0);

async function main() {
  console.log("Seeding Rutina 2.0 ...");

  // wipe
  await db.transaction.deleteMany({});
  await db.wallet.deleteMany({});
  await db.habitLog.deleteMany({});
  await db.habit.deleteMany({});
  await db.workout.deleteMany({});
  await db.foodEntry.deleteMany({});
  await db.foodItem.deleteMany({});
  await db.checkIn.deleteMany({});
  await db.bodyMetric.deleteMany({});
  await db.exercise.deleteMany({});
  await db.journalEntry.deleteMany({});
  await db.budget.deleteMany({});
  await db.savingsGoal.deleteMany({});
  await db.achievement.deleteMany({});
  await db.quote.deleteMany({});
  await db.profile.deleteMany({});

  await db.profile.create({
    data: {
      id: "main",
      name: "Dimas",
      identityVoice:
        "Aku adalah orang yang konsisten, tenang di bawah tekanan, dan tumbuh 1% setiap hari.",
      dailyMissionTarget: 4,
    },
  });

  // ============ HABITS ============
  const habitDefs = [
    {
      name: "Minum 8 gelas air",
      category: "health", icon: "glass-water", color: "teal", scheduleType: "daily",
      daysOfWeek: "0,1,2,3,4,5,6", timeOfDay: "anytime",
      unitLabel: "gelas", unitTarget: 8, unitStep: 1, consistency: 0.88, measured: true,
      reminderTime: "09:00",
    },
    {
      name: "Olahraga pagi",
      category: "health", icon: "dumbbell", color: "orange", scheduleType: "custom",
      daysOfWeek: "1,3,5", timeOfDay: "morning", consistency: 0.75,
      reminderTime: "06:00",
    },
    {
      name: "Baca 10 halaman",
      category: "mind", icon: "book-open", color: "rose", scheduleType: "daily",
      daysOfWeek: "0,1,2,3,4,5,6", timeOfDay: "evening",
      unitLabel: "halaman", unitTarget: 10, unitStep: 5, consistency: 0.7, measured: true,
      reminderTime: "20:30",
    },
    {
      name: "Jurnal malam",
      category: "mind", icon: "notebook-pen", color: "writer" as unknown as string, scheduleType: "daily",
      daysOfWeek: "0,1,2,3,4,5,6", timeOfDay: "evening", consistency: 0.65,
      reminderTime: "21:30",
    },
    {
      name: "Meditasi 10 menit",
      category: "mind", icon: "flower-2", color: "amber", scheduleType: "daily",
      daysOfWeek: "0,1,2,3,4,5,6", timeOfDay: "morning",
      unitLabel: "menit", unitTarget: 10, unitStep: 5, consistency: 0.6, measured: true,
    },
    {
      name: "Catat keuangan",
      category: "finance", icon: "wallet-cards", color: "teal", scheduleType: "daily",
      daysOfWeek: "0,1,2,3,4,5,6", timeOfDay: "evening", consistency: 0.82,
      reminderTime: "20:00", stackAfter: "Setelah makan malam",
    },
    {
      name: "Belajar bahasa Inggris",
      category: "learning", icon: "languages", color: "amber", scheduleType: "custom",
      daysOfWeek: "1,2,4,6", timeOfDay: "afternoon",
      unitLabel: "menit", unitTarget: 15, unitStep: 5, consistency: 0.72, measured: true,
      reminderTime: "16:00",
    },
    {
      name: "Rapikan meja kerja",
      category: "productivity", icon: "sparkles", color: "stone", scheduleType: "custom",
      daysOfWeek: "1,2,3,4,5", timeOfDay: "afternoon", consistency: 0.78,
      stackAfter: "Setelah selesai kerja",
    },
    {
      name: "Hubungi keluarga",
      category: "social", icon: "phone", color: "rose", scheduleType: "custom",
      daysOfWeek: "0", timeOfDay: "anytime", consistency: 0.9,
      reminderTime: "10:00",
    },
  ];

  const habits: { id: string; consistency: number; measured: boolean; days: number[] }[] = [];
  for (const h of habitDefs) {
    const created = await db.habit.create({
      data: {
        name: h.name,
        category: h.category,
        icon: h.icon,
        color: h.color === ("writer" as string) ? "rose" : h.color,
        scheduleType: h.scheduleType,
        daysOfWeek: h.daysOfWeek,
        timeOfDay: h.timeOfDay,
        unitLabel: h.unitLabel ?? null,
        unitTarget: h.unitTarget ?? null,
        unitStep: h.unitStep ?? 1,
        reminderTime: h.reminderTime ?? null,
        stackAfter: h.stackAfter ?? null,
      },
    });
    habits.push({
      id: created.id,
      consistency: h.consistency,
      measured: !!h.measured,
      days: h.daysOfWeek.split(",").map(Number),
    });
  }

  // Logs 35 hari dengan pola realistis + streak terkini yang bagus
  for (let off = 35; off >= 0; off--) {
    const date = dstr(off);
    const dow = new Date(date + "T00:00:00").getDay();
    for (const h of habits) {
      if (!h.days.includes(dow)) continue;
      // 6 hari terakhir konsisten done agar streak terlihat
      const boost = off <= 5 ? 0.98 : h.consistency;
      const roll = rand();
      if (roll < boost) {
        const value = h.measured
          ? h.id === habits[0].id
            ? rint(6, 8)
            : rint(8, 12)
          : null;
        await db.habitLog.create({
          data: { habitId: h.id, date, status: "done", value },
        });
      } else if (roll < boost + 0.06 && off > 10) {
        await db.habitLog.create({ data: { habitId: h.id, date, status: "rest" } });
      } else if (off > 5) {
        await db.habitLog.create({ data: { habitId: h.id, date, status: "missed" } });
      }
    }
  }

  // ============ EXERCISES ============
  const exerciseDefs: [string, string, string | null][] = [
    ["Bench Press", "chest", "Barbell"],
    ["Incline Dumbbell Press", "chest", "Dumbbell"],
    ["Push-up", "chest", null],
    ["Deadlift", "back", "Barbell"],
    ["Barbell Row", "back", "Barbell"],
    ["Pull-up", "back", null],
    ["Lat Pulldown", "back", "Machine"],
    ["Overhead Press", "shoulders", "Barbell"],
    ["Lateral Raise", "shoulders", "Dumbbell"],
    ["Bicep Curl", "arms", "Dumbbell"],
    ["Tricep Rope Pushdown", "arms", "Cable"],
    ["Squat", "legs", "Barbell"],
    ["Leg Press", "legs", "Machine"],
    ["Romanian Deadlift", "legs", "Barbell"],
    ["Walking Lunge", "legs", "Dumbbell"],
    ["Plank", "core", null],
    ["Hanging Leg Raise", "core", null],
  ];
  for (const [name, mg, eq] of exerciseDefs) {
    await db.exercise.create({ data: { name, muscleGroup: mg, equipment: eq } });
  }

  // ============ WORKOUTS (30 hari) ============
  const strengthTemplates = [
    { title: "Push Day — Dada & Bahu", items: [["Bench Press", "chest"], ["Incline Dumbbell Press", "chest"], ["Overhead Press", "shoulders"], ["Lateral Raise", "shoulders"], ["Tricep Rope Pushdown", "arms"]] },
    { title: "Pull Day — Punggung", items: [["Deadlift", "back"], ["Barbell Row", "back"], ["Lat Pulldown", "back"], ["Pull-up", "back"], ["Bicep Curl", "arms"]] },
    { title: "Leg Day — Kaki", items: [["Squat", "legs"], ["Leg Press", "legs"], ["Romanian Deadlift", "legs"], ["Walking Lunge", "legs"], ["Hanging Leg Raise", "core"]] },
  ];
  const baseWeights: Record<string, number> = {
    "Bench Press": 55, "Incline Dumbbell Press": 20, "Overhead Press": 35,
    "Lateral Raise": 8, "Tricep Rope Pushdown": 25, "Deadlift": 90, "Barbell Row": 50,
    "Lat Pulldown": 45, "Pull-up": 0, "Bicep Curl": 12, "Squat": 70, "Leg Press": 120,
    "Romanian Deadlift": 55, "Walking Lunge": 10, "Hanging Leg Raise": 0,
  };

  for (let off = 30; off >= 0; off--) {
    const date = dstr(off);
    const dow = new Date(date + "T00:00:00").getDay();
    const roll = rand();
    if (dow === 1 || dow === 3 || dow === 5) {
      if (roll < 0.8) {
        // strength session
        const tpl = pick(strengthTemplates);
        const items = tpl.items.map(([ex, mg]) => {
          const bw = baseWeights[ex] ?? 20;
          const progress = (30 - off) * 0.35; // progresi beban pelan
          return {
            exercise: ex,
            muscleGroup: mg,
            weight: Math.max(0, Math.round((bw + progress * rand()) / 2.5) * 2.5),
            reps: pick([8, 10, 12]),
            sets: rint(3, 4),
          };
        });
        await db.workout.create({
          data: {
            type: "strength", title: tpl.title, date, startTime: "06:30",
            durationMin: rint(55, 75), calories: rint(280, 420),
            strength: JSON.stringify(items),
            notes: rand() < 0.3 ? "Progression bagus minggu ini" : null,
          },
        });
      }
    } else if ((dow === 2 || dow === 6) && roll < 0.65) {
      // cardio
      const t = pick(["run", "runwalk", "walk", "badminton"] as const);
      const dist = t === "run" ? rfloat(3.2, 6.5) : t === "runwalk" ? rfloat(4, 7) : t === "walk" ? rfloat(3, 5) : null;
      await db.workout.create({
        data: {
          type: t, date, startTime: pick(["06:15", "06:45", "17:30"]),
          durationMin: t === "badminton" ? rint(60, 90) : rint(25, 55),
          distanceKm: dist,
          paceMin: dist ? rfloat(5.3, 6.4, 2) : null,
          calories: t === "badminton" ? rint(400, 560) : rint(180, 420),
          notes: t === "run" && rand() < 0.4 ? "Easy pace, nikmati rute baru" : null,
        },
      });
    }
  }

  // ============ FOOD ITEMS ============
  const foods: [string, number, number, number, number, string][] = [
    ["Nasi Goreng Spesial", 743, 22, 98, 26, "1 piring"],
    ["Nasi Putih", 205, 4.3, 45, 0.5, "1 mangkuk"],
    ["Dada Ayam Panggang", 165, 31, 0, 3.6, "100 g"],
    ["Ayam Goreng", 510, 28, 32, 28, "1 potong"],
    ["Sate Ayam", 480, 34, 25, 24, "10 tusuk"],
    ["Tempe Goreng", 118, 11, 8, 6, "1 potong"],
    ["Tahu Goreng", 80, 8, 2, 5, "1 potong"],
    ["Sayur Asem", 90, 3, 14, 3, "1 mangkuk"],
    ["Telur Rebus", 78, 6.3, 0.6, 5.3, "1 butir"],
    ["Oatmeal Susu", 220, 8, 34, 6, "1 mangkuk"],
    ["Roti Bakar Telur", 320, 15, 30, 15, "2 lembar"],
    ["Pisang", 105, 1.3, 27, 0.4, "1 buah"],
    ["Yogurt Greek", 110, 10, 8, 4, "1 cup"],
    ["Smoothie Buah", 210, 4, 46, 2, "1 gelas"],
    ["Es Teh Manis", 90, 0, 22, 0, "1 gelas"],
    ["Kopi Susu Gula Aren", 120, 2, 18, 4, "1 gelas"],
    ["Mie Goreng", 430, 12, 58, 16, "1 porsi"],
    ["Bakso Sapi", 380, 20, 40, 15, "1 mangkuk"],
    ["Ubi Rebus", 115, 2, 27, 0.1, "100 g"],
    ["Almond Panggang", 164, 6, 6, 14, "28 g"],
  ];
  for (const [name, cal, p, c, f, serving] of foods) {
    await db.foodItem.create({ data: { name, calories: cal, protein: p, carbs: c, fat: f, serving } });
  }

  // ============ FOOD ENTRIES (7 hari) ============
  for (let off = 6; off >= 0; off--) {
    const date = dstr(off);
    const breakfast = pick(foods.filter((f) => f[0].match(/Oatmeal|Roti|Telur|Kopi|Pisang|Ubi/)));
    const lunch = pick(foods.filter((f) => f[0].match(/Nasi|Sate|Mie|Bakso|Ayam/)));
    const dinner = pick(foods.filter((f) => f[0].match(/Sayur|Tempe|Tahu|Nasi|Bakso/)));
    const snack = pick(foods.filter((f) => f[0].match(/Pisang|Yogurt|Almond|Smoothie|Es Teh/)));
    const entries = [
      { name: breakfast[0], calories: breakfast[1], protein: breakfast[2], carbs: breakfast[3], fat: breakfast[4], meal: "breakfast", portion: breakfast[5] },
      { name: lunch[0], calories: lunch[1], protein: lunch[2], carbs: lunch[3], fat: lunch[4], meal: "lunch", portion: lunch[5] },
      { name: dinner[0], calories: dinner[1], protein: dinner[2], carbs: dinner[3], fat: dinner[4], meal: "dinner", portion: dinner[5] },
    ];
    if (rand() < 0.7) entries.push({ name: snack[0], calories: snack[1], protein: snack[2], carbs: snack[3], fat: snack[4], meal: "snack", portion: snack[5] });
    for (const e of entries) {
      await db.foodEntry.create({ data: { ...e, date } });
    }
  }

  // ============ CHECK-INS (14 hari) ============
  for (let off = 13; off >= 0; off--) {
    const date = dstr(off);
    await db.checkIn.create({
      data: {
        date,
        mood: rint(3, 5),
        energy: rint(2, 5),
        soreness: rint(1, 4),
        stress: rint(1, 4),
        sleepHours: rfloat(6, 8.5, 1),
        note: rand() < 0.2 ? pick(["Badan pegal setelah leg day", "Semangat hari Senin", "Tidur cukup, fokus meningkat"]) : null,
      },
    });
  }

  // ============ BODY METRICS (30 hari) ============
  let weight = 68.9;
  for (let off = 29; off >= 0; off--) {
    weight -= 0.045 + (rand() - 0.5) * 0.09;
    await db.bodyMetric.create({
      data: {
        date: dstr(off),
        weightKg: Number(weight.toFixed(1)),
        hydrationGlasses: rint(5, 8),
      },
    });
  }

  // ============ WALLETS ============
  const wTunai = await db.wallet.create({ data: { name: "Tunai", type: "cash", initialBalance: 500000, color: "amber", icon: "banknote" } });
  const wBCA = await db.wallet.create({ data: { name: "BCA", type: "bank", initialBalance: 8500000, color: "vault", icon: "landmark" } });
  const wGoPay = await db.wallet.create({ data: { name: "GoPay", type: "ewallet", initialBalance: 250000, color: "garden", icon: "smartphone" } });

  // ============ TRANSACTIONS (35 hari) ============
  const catExpense: [string, number, number, string[]][] = [
    ["makan", 15000, 55000, ["Sarapan bubur", "Kopi pagi", "Makan siang warteg", "Ayam geprek", "Nasi padang", "Sate kelas", "Bakso pinggir jalan", "Dinner bareng teman"]],
    ["transport", 12000, 45000, ["Ojol ke kantor", "Pulang kerja", "Bensin motor", "Ojol ke klien"]],
    ["hiburan", 25000, 120000, ["Nonton bioskop", "Streaming weekend", "Main futsal", "Ngopi sore"]],
    ["belanja", 50000, 450000, ["Belanja mingguan", "Kaos olahraga", "Skincare", "Buku baru", "Perlengkapan rumah"]],
    ["kesehatan", 30000, 200000, ["Vitamin C", "Obat sakit kepala", "Membership gym", "Cek kesehatan"]],
    ["edukasi", 50000, 350000, ["Langganan course", "Buku pengembangan diri", "Ielts practice test"]],
    ["tagihan", 150000, 800000, ["Listrik & air", "Internet rumah", "Paket data", "IPL gedung"]],
  ];
  for (let off = 34; off >= 0; off--) {
    const date = dstr(off);
    const dow = new Date(date + "T00:00:00").getDay();
    // Gaji tiap tanggal 1
    const day = Number(date.slice(8));
    if (day === 1) {
      await db.transaction.create({
        data: { type: "income", amount: 8500000, category: "gaji", walletId: wBCA.id, date, note: "Gaji bulanan", recurring: "monthly" },
      });
    }
    if (dow === 6 && rand() < 0.6) {
      await db.transaction.create({
        data: { type: "income", amount: rint(300, 900) * 1000, category: "freelance", walletId: wBCA.id, date, note: pick(["Proyek desain landing page", "Konsultasi website", "Setup toko online"]) },
      });
    }
    // Netflix & Spotify
    if (day === 5) {
      await db.transaction.create({ data: { type: "expense", amount: 54000, category: "hiburan", walletId: wBCA.id, date, note: "Netflix", recurring: "monthly" } });
      await db.transaction.create({ data: { type: "expense", amount: 27000, category: "hiburan", walletId: wGoPay.id, date, note: "Spotify", recurring: "monthly" } });
    }
    // Tagihan terjadwal (realistis): IPL tgl 1, listrik tgl 2, internet tgl 10, paket data tgl 20
    if (day === 1) await db.transaction.create({ data: { type: "expense", amount: 350000, category: "tagihan", walletId: wBCA.id, date, note: "IPL gedung", recurring: "monthly" } });
    if (day === 2) await db.transaction.create({ data: { type: "expense", amount: 465000, category: "tagihan", walletId: wBCA.id, date, note: "Listrik & air", recurring: "monthly" } });
    if (day === 10) await db.transaction.create({ data: { type: "expense", amount: 320000, category: "tagihan", walletId: wBCA.id, date, note: "Internet rumah", recurring: "monthly" } });
    if (day === 20) await db.transaction.create({ data: { type: "expense", amount: 150000, category: "tagihan", walletId: wBCA.id, date, note: "Paket data", recurring: "monthly" } });
    // Belanja mingguan Sabtu
    if (dow === 6) {
      await db.transaction.create({ data: { type: "expense", amount: rint(120000, 300000), category: "belanja", walletId: wBCA.id, date, note: pick(["Belanja mingguan", "Stok dapur", "Kebutuhan rumah"]) } });
      if (rand() < 0.3) await db.transaction.create({ data: { type: "expense", amount: rint(50000, 250000), category: "belanja", walletId: wBCA.id, date, note: pick(["Kaos olahraga", "Buku baru", "Skincare"]) } });
    }
    // Kesehatan & edukasi jarang
    if (rand() < 0.1) await db.transaction.create({ data: { type: "expense", amount: rint(30000, 200000), category: "kesehatan", walletId: wBCA.id, date, note: pick(["Vitamin C", "Obat sakit kepala", "Membership gym"]) } });
    if (rand() < 0.08) await db.transaction.create({ data: { type: "expense", amount: rint(50000, 350000), category: "edukasi", walletId: wBCA.id, date, note: pick(["Langganan course", "Buku pengembangan diri"]) } });
    // Transfers topup GoPay tiap minggu
    if (dow === 1 && rand() < 0.8) {
      await db.transaction.create({ data: { type: "transfer", amount: 200000, category: "lainnya", walletId: wBCA.id, toWalletId: wGoPay.id, date, note: "Top up GoPay" } });
      await db.transaction.create({ data: { type: "transfer", amount: 800000, category: "lainnya", walletId: wBCA.id, toWalletId: wTunai.id, date, note: "Tarik tunai mingguan" } });
    }
    // Daily expenses 2-3 (kategori kecil: makan/transport/hiburan)
    const smallCats: [string, number, number, string[]][] = [
      ["makan", 15000, 55000, ["Sarapan bubur", "Kopi pagi", "Makan siang warteg", "Ayam geprek", "Nasi padang", "Sate kelas", "Bakso pinggir jalan", "Dinner bareng teman"]],
      ["transport", 12000, 45000, ["Ojol ke kantor", "Pulang kerja", "Bensin motor", "Ojol ke klien"]],
      ["hiburan", 25000, 90000, ["Nonton bioskop", "Streaming weekend", "Main futsal", "Ngopi sore"]],
    ];
    const n = rint(2, 3);
    for (let i = 0; i < n; i++) {
      const [cat, lo, hi, notes] = pick(smallCats);
      const walletId = pick([wTunai.id, wTunai.id, wGoPay.id, wBCA.id]);
      await db.transaction.create({
        data: {
          type: "expense", amount: rint(lo, hi), category: cat,
          walletId,
          date, note: pick(notes),
        },
      });
    }
  }

  // ============ BUDGETS ============
  const budgets: [string, number][] = [
    ["makan", 1500000], ["transport", 600000], ["hiburan", 1400000],
    ["belanja", 1000000], ["kesehatan", 400000], ["edukasi", 900000], ["tagihan", 1400000],
  ];
  for (const [cat, limit] of budgets) {
    await db.budget.create({ data: { category: cat, monthlyLimit: limit } });
  }

  // ============ GOALS ============
  await db.savingsGoal.create({ data: { name: "Dana Darurat", targetAmount: 20000000, currentAmount: 6500000, color: "vault", icon: "shield-check" } });
  await db.savingsGoal.create({ data: { name: "Laptop Baru", targetAmount: 15000000, currentAmount: 4200000, deadline: dstr(-120), color: "gold", icon: "laptop" } });
  await db.savingsGoal.create({ data: { name: "Liburan Bali", targetAmount: 8000000, currentAmount: 2100000, deadline: dstr(-200), color: "studio", icon: "palmtree" } });

  // ============ JOURNAL ============
  const journals = [
    { title: "Minggu yang produktif", content: "Pekan ini aku berhasil menyelesaikan semua misi harian lima hari berturut-turut. Kuncinya ternyata sederhana: persiapkan semuanya di malam hari. Meja yang rapi, botol air yang sudah diisi, dan buku yang sudah terbuka di halaman yang tepat.", folder: "Refleksi", mood: "great", pinned: true, daysAgo: 12 },
    { title: "Mulai program latihan baru", content: "Hari ini push day pertama program 12 pekan. Bench Press 60kg x 8 rep — rekor pribadi kecil yang terasa besar. Aku mencatat setiap set supaya pekan depan ada target konkret yang bisa dilewati.", folder: "Sorotan", mood: "great", pinned: false, daysAgo: 10 },
    { title: "Tentang melewatkan satu hari", content: "Kemarin aku melewatkan meditasi dan membaca. Terasa ingin menyerah total, tapi coach di aplikasi mengingatkan: satu hari buruk tidak menghapus 20 hari baik. Hari ini aku mulai lagi, tanpa drama.", folder: "Refleksi", mood: "neutral", pinned: false, daysAgo: 8 },
    { title: "Ide proyek sampingan", content: "Kalau rutinitas finansialku sudah stabil tiga bulan, aku ingin membangun tools kecil untuk pelacakan langganan. Banyak teman membayar layanan yang sudah tidak mereka pakai.", folder: "Ide", mood: "good", pinned: false, daysAgo: 6 },
    { title: "Neraca kalori pertama yang masuk akal", content: "Setelah dua minggu mencatat asupan, polanya kelihatan: kaloriku naik di akhir pekan karena jajan bareng teman. Bukan masalah besar — cukup geser porsi makan malam saat hari sabtu aktif.", folder: "Umum", mood: "good", pinned: false, daysAgo: 5 },
    { title: "Berat badan turun 1.2 kg", content: "Tiga puluh hari konsisten: 68.9 menjadi 67.7 kg. Perubahannya lambat, tapi ini bukan diet — ini gaya hidup yang bisa dijalankan selamanya.", folder: "Sorotan", mood: "great", pinned: true, daysAgo: 3 },
    { title: "Hari yang berat", content: "Deadline menumpuk dan aku tidur terlalu sedikit. Aku memilih hari jeda untuk kebiasaan baca malam ini, dan itu tidak membuatku gagal. Besok aku mulai lagi.", folder: "Refleksi", mood: "tough", pinned: false, daysAgo: 1 },
  ];
  for (const j of journals) {
    await db.journalEntry.create({
      data: {
        title: j.title,
        content: j.content,
        folder: j.folder,
        mood: j.mood,
        pinned: j.pinned,
        wordCount: j.content.split(/\s+/).length,
        createdAt: new Date(Date.now() - j.daysAgo * 86400000),
        updatedAt: new Date(Date.now() - j.daysAgo * 86400000),
      },
    });
  }

  // ============ QUOTES ============
  const quotes: [string, string][] = [
    ["Kamu tidak harus luar biasa untuk memulai, tapi kamu harus memulai untuk menjadi luar biasa.", "Zig Ziglar"],
    ["Konsistensi kecil yang diulang setiap hari mengalahkan usaha besar yang hanya sesekali.", "Robin Sharma"],
    ["Disiplin adalah memilih antara apa yang kamu inginkan sekarang dan apa yang kamu inginkan paling.", "Abraham Lincoln"],
    ["Perubahan terbesar dimulai dari langkah terkecil yang tidak kamu lewatkan hari ini.", "James Clear"],
    ["Kebiasaan baik adalah bunga dari keputusan baik yang diulang dengan sabar.", "Anonim"],
    ["Yang menghentikanmu bukan kegagalan, tapi berhentilah mencoba setelahnya.", "Anonim"],
    ["Kalender, bukan motivasi, adalah teman terbaik dari konsistensi.", "Anonim"],
    ["Investasi terbaik adalah yang kamu lakukan pada dirimu sendiri, sedikit demi sedikit.", "Warren Buffett"],
    ["Tenang adalah keahlian. Latih setiap hari seperti melatih otot.", "Anonim"],
    ["Hari ini adalah kesempatan untuk membangun versi dirimu yang lebih baik.", "Anonim"],
  ];
  for (const [text, author] of quotes) {
    await db.quote.create({ data: { text, author } });
  }

  // ============ ACHIEVEMENTS ============
  const achievements: [string, string, string, string, string | null][] = [
    ["first-habit", "Langkah Pertama", "Selesaikan kebiasaan pertama", "sprout", dstr(33)],
    ["streak-7", "Minggu Mantap", "Pertahankan streak 7 hari", "flame", dstr(25)],
    ["streak-21", "Tiga Pekan Konsisten", "Pertahankan streak 21 hari", "flame", null],
    ["first-workout", "Sesi Pertama", "Selesaikan latihan pertama", "dumbbell", dstr(30)],
    ["workout-10", "Sepuluh Sesi", "Selesaikan 10 sesi latihan", "medal", dstr(14)],
    ["workout-50", "Setengah Ratus", "Selesaikan 50 sesi latihan", "trophy", null],
    ["first-journal", "Tinta Pertama", "Tulis jurnal pertama", "pen-line", dstr(12)],
    ["journal-10", "Penulis Rutin", "Tulis 10 catatan jurnal", "notebook-pen", dstr(1)],
    ["budget-keeper", "Penjaga Anggaran", "Patuhi anggaran kategori sebulan penuh", "piggy-bank", dstr(9)],
    ["saver-1jt", "Pemula Menabung", "Capai 1 juta di tujuan tabungan", "wallet", dstr(20)],
    ["checkin-7", "Sadar Diri", "Check-in 7 hari berbeda", "heart-pulse", dstr(7)],
    ["level-5", "Naik Kelas", "Capai level 5", "crown", null],
  ];
  for (const [key, title, description, icon, unlockedAt] of achievements) {
    await db.achievement.create({ data: { key, title, description, icon, unlockedAt } });
  }

  const counts = {
    habits: await db.habit.count(),
    logs: await db.habitLog.count(),
    workouts: await db.workout.count(),
    transactions: await db.transaction.count(),
    journals: await db.journalEntry.count(),
  };
  console.log("Seed selesai:", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
